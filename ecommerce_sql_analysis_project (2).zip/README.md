
# E-Commerce SQL Analysis

This project contains SQL queries to analyze data from an e-commerce database. The goal is to provide insights on sales performance, customer behavior, employee performance, and more.

## Structure

- `/queries/`: Contains all SQL queries used for the analysis.
- `/docs/`: Contains documentation, including the executive summary of insights.
- `/images/`: Optional images (e.g., schema diagram, ERD).
- `/mock_data/`: Optional mock data files for testing.

## SQL Queries

Each SQL query corresponds to a specific business question, such as:

1. **Total Sales by Employee**
2. **Top 5 Customers by Sales**
3. **Monthly Sales Trend**
4. **Order Fulfilment Time**
5. **Products by Category with No Sales**
6. **Customers with Multiple Orders on the Same Date**
7. **Average Discount per Product**
8. **Products Ordered by Each Customer**
9. **Employee Sales Ranking**
10. **Sales by Country and Category**
11. **Year-over-Year Sales Growth**
12. **Order Quantity Percentile**
13. **Products Never Reordered**
14. **Most Valuable Product by Revenue**
15. **Complex Order Details**

## Executive Summary

An executive summary of insights will be provided in `/docs/executive_summary.md`. This document will include key takeaways from the SQL analysis.

## How to Use

To run these queries, use any SQL client (e.g., MySQL Workbench, DBeaver) and connect to your e-commerce database. Copy and paste the queries from `/queries/` into your SQL client and execute them to get the results.

## License

This project is licensed under the MIT License - see the [LICENSE](./LICENSE) file for details.
