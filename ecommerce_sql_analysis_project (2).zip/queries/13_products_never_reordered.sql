
-- Query to identify products that have been sold but have never been reordered.
-- These products have only appeared in one order.
SELECT 
    p.ProductID,
    p.ProductName,
    COUNT(od.OrderDetailID) AS OrderCount
FROM 
    Products p
JOIN OrderDetails od ON p.ProductID = od.ProductID
GROUP BY 
    p.ProductID
HAVING 
    COUNT(od.OrderDetailID) = 1
ORDER BY 
    p.ProductName;
