
-- Query to calculate total sales by each employee.
-- This considers the quantity and unit price of products sold.
SELECT 
    e.EmployeeID,
    CONCAT(e.FirstName, ' ', e.LastName) AS EmployeeName,
    SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)) AS TotalSales
FROM 
    Orders o
JOIN OrderDetails od ON o.OrderID = od.OrderID
JOIN Employees e ON o.EmployeeID = e.EmployeeID
GROUP BY 
    e.EmployeeID
ORDER BY 
    TotalSales DESC;
