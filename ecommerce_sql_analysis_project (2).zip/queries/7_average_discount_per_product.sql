
-- Query to calculate the average discount given per product across all orders.
-- The discount is calculated on a per-product basis.
SELECT 
    p.ProductID,
    p.ProductName,
    ROUND(AVG(od.Discount), 2) AS AvgDiscount
FROM 
    OrderDetails od
JOIN Products p ON od.ProductID = p.ProductID
GROUP BY 
    p.ProductID
ORDER BY 
    AvgDiscount DESC;
