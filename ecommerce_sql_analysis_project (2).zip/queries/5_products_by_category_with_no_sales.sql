
-- Query to list products by category that have never been sold.
-- This identifies products with no orders associated with them.
SELECT 
    p.ProductID,
    p.ProductName,
    c.CategoryName
FROM 
    Products p
JOIN Categories c ON p.CategoryID = c.CategoryID
LEFT JOIN OrderDetails od ON p.ProductID = od.ProductID
WHERE 
    od.OrderDetailID IS NULL
ORDER BY 
    c.CategoryName, p.ProductName;
