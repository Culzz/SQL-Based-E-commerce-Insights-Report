
-- Query to calculate the average time (in days) taken to fulfill an order for each employee.
-- Shipping time depends on whether the order was placed in 1996 or 1997.
SELECT 
    e.EmployeeID,
    CONCAT(e.FirstName, ' ', e.LastName) AS EmployeeName,
    AVG(DATEDIFF(o.ShippedDate, o.OrderDate)) AS AvgFulfilmentTime
FROM 
    Orders o
JOIN Employees e ON o.EmployeeID = e.EmployeeID
WHERE 
    YEAR(o.OrderDate) IN (1996, 1997)
GROUP BY 
    e.EmployeeID
ORDER BY 
    AvgFulfilmentTime;
