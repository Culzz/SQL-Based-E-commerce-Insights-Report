
-- Query to calculate the percentile rank of each order based on the total quantity of products in the order.
SELECT 
    o.OrderID,
    SUM(od.Quantity) AS TotalQuantity,
    PERCENT_RANK() OVER (ORDER BY SUM(od.Quantity) DESC) AS QuantityPercentile
FROM 
    OrderDetails od
JOIN Orders o ON od.OrderID = o.OrderID
GROUP BY 
    o.OrderID
ORDER BY 
    QuantityPercentile DESC;
