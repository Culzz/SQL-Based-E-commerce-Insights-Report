
-- Query to rank employees based on their total sales.
-- Employees are ranked by total sales in descending order.
SELECT 
    e.EmployeeID,
    CONCAT(e.FirstName, ' ', e.LastName) AS EmployeeName,
    SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)) AS TotalSales,
    RANK() OVER (ORDER BY SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)) DESC) AS SalesRank
FROM 
    Orders o
JOIN OrderDetails od ON o.OrderID = od.OrderID
JOIN Employees e ON o.EmployeeID = e.EmployeeID
GROUP BY 
    e.EmployeeID
ORDER BY 
    SalesRank;
