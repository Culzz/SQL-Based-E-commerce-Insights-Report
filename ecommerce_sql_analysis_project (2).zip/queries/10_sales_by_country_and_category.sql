
-- Query to display the total sales amount for each product category, grouped by country.
SELECT 
    c.Country,
    cat.CategoryName,
    SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)) AS TotalSales
FROM 
    Orders o
JOIN OrderDetails od ON o.OrderID = od.OrderID
JOIN Products p ON od.ProductID = p.ProductID
JOIN Categories cat ON p.CategoryID = cat.CategoryID
JOIN Customers c ON o.CustomerID = c.CustomerID
GROUP BY 
    c.Country, cat.CategoryName
ORDER BY 
    c.Country, cat.CategoryName;
