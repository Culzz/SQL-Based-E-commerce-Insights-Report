
-- Query to calculate the percentage growth in sales from one year to the next for each product.
SELECT 
    p.ProductID,
    p.ProductName,
    YEAR(o.OrderDate) AS Year,
    SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)) AS TotalSales,
    LAG(SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)), 1) 
        OVER (PARTITION BY p.ProductID ORDER BY YEAR(o.OrderDate)) AS PrevYearSales,
    CASE 
        WHEN LAG(SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)), 1) 
            OVER (PARTITION BY p.ProductID ORDER BY YEAR(o.OrderDate)) IS NULL THEN NULL
        ELSE
            (SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)) - 
             LAG(SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)), 1) 
             OVER (PARTITION BY p.ProductID ORDER BY YEAR(o.OrderDate))) / 
             LAG(SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)), 1) 
             OVER (PARTITION BY p.ProductID ORDER BY YEAR(o.OrderDate)) * 100
    END AS SalesGrowthPercentage
FROM 
    Orders o
JOIN OrderDetails od ON o.OrderID = od.OrderID
JOIN Products p ON od.ProductID = p.ProductID
GROUP BY 
    p.ProductID, YEAR(o.OrderDate)
ORDER BY 
    p.ProductID, Year;
