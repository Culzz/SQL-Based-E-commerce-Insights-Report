
-- Query to find the most valuable product by revenue in each category.
SELECT 
    cat.CategoryName,
    p.ProductName,
    SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)) AS TotalRevenue
FROM 
    Products p
JOIN OrderDetails od ON p.ProductID = od.ProductID
JOIN Categories cat ON p.CategoryID = cat.CategoryID
GROUP BY 
    cat.CategoryName, p.ProductName
ORDER BY 
    TotalRevenue DESC
LIMIT 1;
