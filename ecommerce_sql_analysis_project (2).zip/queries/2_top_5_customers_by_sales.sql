
-- Query to identify top 5 customers by total sales.
-- This ranks customers based on the total amount spent on all orders.
SELECT 
    c.CustomerID,
    c.CustomerName,
    SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)) AS TotalSpent
FROM 
    Orders o
JOIN OrderDetails od ON o.OrderID = od.OrderID
JOIN Customers c ON o.CustomerID = c.CustomerID
GROUP BY 
    c.CustomerID, c.CustomerName
ORDER BY 
    TotalSpent DESC
LIMIT 5;
