
-- Query to list products ordered by each customer along with the total quantity of each product ordered.
SELECT 
    c.CustomerID,
    c.CustomerName,
    p.ProductName,
    SUM(od.Quantity) AS TotalQuantityOrdered
FROM 
    Orders o
JOIN OrderDetails od ON o.OrderID = od.OrderID
JOIN Products p ON od.ProductID = p.ProductID
JOIN Customers c ON o.CustomerID = c.CustomerID
GROUP BY 
    c.CustomerID, p.ProductID
ORDER BY 
    c.CustomerName, TotalQuantityOrdered DESC;
