
-- Query to find customers who have placed multiple orders on the same date.
SELECT 
    o.CustomerID,
    c.CustomerName,
    o.OrderDate,
    COUNT(o.OrderID) AS OrderCount
FROM 
    Orders o
JOIN Customers c ON o.CustomerID = c.CustomerID
GROUP BY 
    o.CustomerID, o.OrderDate
HAVING 
    COUNT(o.OrderID) > 1;
