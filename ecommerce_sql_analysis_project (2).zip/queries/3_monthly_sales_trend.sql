
-- Query to display the total sales amount for each month in the year 1997.
-- This aggregates the sales per month and year.
SELECT 
    MONTH(o.OrderDate) AS Month,
    SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)) AS TotalSales
FROM 
    Orders o
JOIN OrderDetails od ON o.OrderID = od.OrderID
WHERE 
    YEAR(o.OrderDate) = 1997
GROUP BY 
    MONTH(o.OrderDate)
ORDER BY 
    Month;
