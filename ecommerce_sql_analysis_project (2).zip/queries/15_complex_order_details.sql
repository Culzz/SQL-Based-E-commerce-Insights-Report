
-- Query to identify orders where the total price of all items exceeds $100 
-- and contains at least one product with a discount of 5% or more.
SELECT 
    o.OrderID,
    SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)) AS TotalOrderPrice,
    MAX(od.Discount) AS MaxDiscount
FROM 
    OrderDetails od
JOIN Orders o ON od.OrderID = o.OrderID
GROUP BY 
    o.OrderID
HAVING 
    TotalOrderPrice > 100 AND MaxDiscount >= 0.05;
